![project1](D:\poly_ict\off_2023\woojae\project1.PNG)

![project2](D:\poly_ict\off_2023\woojae\project2.PNG)

![project3](D:\poly_ict\off_2023\woojae\project3.PNG)

![project4](D:\poly_ict\off_2023\woojae\project4.PNG)

![project5](D:\poly_ict\off_2023\woojae\project5.PNG)

![project6](D:\poly_ict\off_2023\woojae\project6.PNG)

![project7](D:\poly_ict\off_2023\woojae\project7.PNG)

![project8](D:\poly_ict\off_2023\woojae\project8.PNG)

![project9](D:\poly_ict\off_2023\woojae\project9.PNG)

![project10](D:\poly_ict\off_2023\woojae\project10.PNG)

![project11](D:\poly_ict\off_2023\woojae\project11.PNG)

![project12](D:\poly_ict\off_2023\woojae\project12.PNG)

![project13](D:\poly_ict\off_2023\woojae\project13.PNG)

![project14](D:\poly_ict\off_2023\woojae\project14.PNG)

![project15](D:\poly_ict\off_2023\woojae\project15.PNG)

![project16](D:\poly_ict\off_2023\woojae\project16.PNG)

![project17](D:\poly_ict\off_2023\woojae\project17.PNG)